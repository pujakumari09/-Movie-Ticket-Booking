'use strict';

var proxyquire = require('proxyquire').noPreserveCache();

var threaterendpointCtrlStub = {
  index: 'threaterendpointCtrl.index',
  show: 'threaterendpointCtrl.show',
  create: 'threaterendpointCtrl.create',
  update: 'threaterendpointCtrl.update',
  destroy: 'threaterendpointCtrl.destroy'
};

var routerStub = {
  get: sinon.spy(),
  put: sinon.spy(),
  patch: sinon.spy(),
  post: sinon.spy(),
  delete: sinon.spy()
};

// require the index with our stubbed out modules
var threaterendpointIndex = proxyquire('./index.js', {
  'express': {
    Router: function() {
      return routerStub;
    }
  },
  './threaterendpoint.controller': threaterendpointCtrlStub
});

describe('Threaterendpoint API Router:', function() {

  it('should return an express router instance', function() {
    expect(threaterendpointIndex).to.equal(routerStub);
  });

  describe('GET /api/threaterendpoints', function() {

    it('should route to threaterendpoint.controller.index', function() {
      expect(routerStub.get
        .withArgs('/', 'threaterendpointCtrl.index')
        ).to.have.been.calledOnce;
    });

  });

  describe('GET /api/threaterendpoints/:id', function() {

    it('should route to threaterendpoint.controller.show', function() {
      expect(routerStub.get
        .withArgs('/:id', 'threaterendpointCtrl.show')
        ).to.have.been.calledOnce;
    });

  });

  describe('POST /api/threaterendpoints', function() {

    it('should route to threaterendpoint.controller.create', function() {
      expect(routerStub.post
        .withArgs('/', 'threaterendpointCtrl.create')
        ).to.have.been.calledOnce;
    });

  });

  describe('PUT /api/threaterendpoints/:id', function() {

    it('should route to threaterendpoint.controller.update', function() {
      expect(routerStub.put
        .withArgs('/:id', 'threaterendpointCtrl.update')
        ).to.have.been.calledOnce;
    });

  });

  describe('PATCH /api/threaterendpoints/:id', function() {

    it('should route to threaterendpoint.controller.update', function() {
      expect(routerStub.patch
        .withArgs('/:id', 'threaterendpointCtrl.update')
        ).to.have.been.calledOnce;
    });

  });

  describe('DELETE /api/threaterendpoints/:id', function() {

    it('should route to threaterendpoint.controller.destroy', function() {
      expect(routerStub.delete
        .withArgs('/:id', 'threaterendpointCtrl.destroy')
        ).to.have.been.calledOnce;
    });

  });

});
