'use strict';

import mongoose from 'mongoose';

var PaymentendpointSchema = new mongoose.Schema({
  MovieName: String,
  Date: String,
  Time: String,
  Theater: String,
  Loc: String,
  Nseats: String,
  Seat: Array,
  Amount: String,
  name: String,
  info: String,
  active: Boolean
});

export default mongoose.model('UserBooking', PaymentendpointSchema);
