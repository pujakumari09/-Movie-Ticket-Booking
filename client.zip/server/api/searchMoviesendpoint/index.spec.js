'use strict';

var proxyquire = require('proxyquire').noPreserveCache();

var searchMoviesendpointCtrlStub = {
  index: 'searchMoviesendpointCtrl.index',
  show: 'searchMoviesendpointCtrl.show',
  create: 'searchMoviesendpointCtrl.create',
  update: 'searchMoviesendpointCtrl.update',
  destroy: 'searchMoviesendpointCtrl.destroy'
};

var routerStub = {
  get: sinon.spy(),
  put: sinon.spy(),
  patch: sinon.spy(),
  post: sinon.spy(),
  delete: sinon.spy()
};

// require the index with our stubbed out modules
var searchMoviesendpointIndex = proxyquire('./index.js', {
  'express': {
    Router: function() {
      return routerStub;
    }
  },
  './searchMoviesendpoint.controller': searchMoviesendpointCtrlStub
});

describe('SearchMoviesendpoint API Router:', function() {

  it('should return an express router instance', function() {
    expect(searchMoviesendpointIndex).to.equal(routerStub);
  });

  describe('GET /api/searchMoviesendpoints', function() {

    it('should route to searchMoviesendpoint.controller.index', function() {
      expect(routerStub.get
        .withArgs('/', 'searchMoviesendpointCtrl.index')
        ).to.have.been.calledOnce;
    });

  });

  describe('GET /api/searchMoviesendpoints/:id', function() {

    it('should route to searchMoviesendpoint.controller.show', function() {
      expect(routerStub.get
        .withArgs('/:id', 'searchMoviesendpointCtrl.show')
        ).to.have.been.calledOnce;
    });

  });

  describe('POST /api/searchMoviesendpoints', function() {

    it('should route to searchMoviesendpoint.controller.create', function() {
      expect(routerStub.post
        .withArgs('/', 'searchMoviesendpointCtrl.create')
        ).to.have.been.calledOnce;
    });

  });

  describe('PUT /api/searchMoviesendpoints/:id', function() {

    it('should route to searchMoviesendpoint.controller.update', function() {
      expect(routerStub.put
        .withArgs('/:id', 'searchMoviesendpointCtrl.update')
        ).to.have.been.calledOnce;
    });

  });

  describe('PATCH /api/searchMoviesendpoints/:id', function() {

    it('should route to searchMoviesendpoint.controller.update', function() {
      expect(routerStub.patch
        .withArgs('/:id', 'searchMoviesendpointCtrl.update')
        ).to.have.been.calledOnce;
    });

  });

  describe('DELETE /api/searchMoviesendpoints/:id', function() {

    it('should route to searchMoviesendpoint.controller.destroy', function() {
      expect(routerStub.delete
        .withArgs('/:id', 'searchMoviesendpointCtrl.destroy')
        ).to.have.been.calledOnce;
    });

  });

});
