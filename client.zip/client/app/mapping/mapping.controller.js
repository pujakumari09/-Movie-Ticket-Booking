'use strict';

(function(){

class MappingComponent {
  constructor($http, $scope, socket) {
    this.$http = $http;
    this.socket = socket;
    this.ThreaterDetail = [];
    this.MovieData = [];
    this.mappingDetail = [];

    $scope.$on('$destroy', function() {
      socket.unsyncUpdates('mappingendpoint');
    });

    $scope.submitForm = function(isValid){
      if(isValid){
        alert('Detail is Valid');
      }
    };
  }

$onInit(){
  this.$http.get('/api/searchMoviesendpoints').then(response => {
      this.MovieData = response.data;
      console.log(this.MovieData);
      this.socket.syncUpdates('searchMoviesendpoints', this.MovieData);
      });
  this.$http.get('/api/threaterendpoints').then(response => {
      this.ThreaterDetail = response.data;
      this.socket.syncUpdates('threaterendpoint', this.ThreaterDetail);
      });
  this.$http.get('/api/mappingendpoints').then(response => {
    this.mappingDetail = response.data;
    this.socket.syncUpdates('mappingendpoint', this.mappingDetail);
  });
}
setData(movies){
  sessionStorage.setItem('MovieData', movies.title);
}
// getposter(name)
// {
//   this.$http.get('/api/searchMoviesendpoints').then(response => {
//     this.mappingDetail = response.data;
//     this.socket.syncUpdates('mappingendpoint', this.mappingDetail);
//   });
//
// }

getPoster(){
//  alert("helllll");
  var mname=this.Mvname;
  var i;
  for(i=0;i<this.MovieData.length;i++)
  {
  //  console.log(this.MovieData);
    if(this.MovieData[i].title==mname)
    {
      this.p = this.MovieData[i].poster_path;
    //  p = this.Mvname;
      console.log(this.p);
  }
  else {
    console.log("no data");
  }

  }
}

addMapping() {
var ShowTime1=document.getElementById("showtime").value;
var ShowDate1=document.getElementById("showdate").value;

this.$http.post('/api/mappingendpoints',{
Poster: this.p,
Mvname: this.Mvname,
Thname: this.Thname,
Lname: this.Lname,
Cname: this.Cname,
ShowTime: ShowTime1,
ShowDate: ShowDate1
});
// var i;
//console.log("show time is"+this.ShowTime);
alert('Details Saved Successfully');
// if(MovieData.title[i]==this.Mvname){
//   var poster = MovieData.poster_path[i]
// }
}

deleteMapping(mappingendpoint) {
  alert('Record Deleted');
  this.$http.delete('/api/mappingendpoints/'+mappingendpoint._id);
}
 }

angular.module('yeomanOnlineTicketBookingApp')
  .component('mapping', {
    templateUrl: 'app/mapping/mapping.html',
    controller: MappingComponent,
    controllerAs: 'mappingCtrl'
  });

})();
