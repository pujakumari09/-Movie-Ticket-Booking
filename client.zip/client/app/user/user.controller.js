'use strict';

(function(){

class UserComponent {
  constructor($http, $scope, socket) {
    this.$http = $http;
    this.socket = socket;
    this.mappingDetail = [];
    this.bookingDetail = [];
    this.k=[];
    this.m=[];
    this.time=[];
    this.date2=[];
    this.date1=[];
    this.s=[];


    $scope.$on('$destroy', function(){
      socket.unsyncUpdates('userendpoint');
    });

    $scope.submitForm = function(isValid){
      if(isValid){
        alert('Detail is Valid');
      }
    };
  }

$onInit() {
//  this.abc();

  this.$http.get('/api/mappingendpoints').then(response => {
    this.mappingDetail = response.data;
    console.log(this.mappingDetail);
    // this.date=[];
    //  for(var  i=0;i<this.mappingDetail.length;i++)
    //  {
    //    this.date=this.mappingDetail[i].ShowDate.split(",");
    //  }
    //    console.log(this.date);
    //  this.date =  document.getElementById("showdate");
      this.k = sessionStorage.getItem('MovieData');
       for(var  i=0;i<this.mappingDetail.length;i++)
       {
         if(this.k==this.mappingDetail[i].Mvname )
         {
            this.time=this.mappingDetail[i].ShowTime.split(",");
         }
         else
         {
           console.log("no data");
         }
       }
         console.log(this.time);
    //     this.time =  document.getElementById("showtime");
    this.socket.syncUpdates('mappingendpoint', this.mappingDetail);
  });

  //  this.k = sessionStorage.getItem('MovieData');
    // alert(this.k);
}

// datedisp()
// {
//   this.date=[];
//    for(var  i=0;i<this.mappingDetail.length;i++)
//    {
//      this.date=this.mappingDetail[i].ShowDate.split(",");
//    }
//      console.log(this.date);
// }

setDetails(){
  var m = this.k;
  sessionStorage.setItem('mdetail',m);
  // alert(m);
  var c = this.Cname;
  sessionStorage.setItem('cdetail',c);
  // alert(c);
  var sd = this.ShowDate;
  sessionStorage.setItem('sddetail',sd);
  // alert(sd);
  var l = this.Lname;
  sessionStorage.setItem('ldetail',l);
  // alert(l);
  var th = this.Thname;
  sessionStorage.setItem('thdetail', th);
  // alert(th);
  var st = this.ShowTime;
  sessionStorage.setItem('stdetail',st);
  // alert(st);
  }
//---------------------------------------------------------------------------------------------
setdate()
{
  console.log("enter");
  this.city =this.Cname;
  console.log("the value of cname"+this.Cname);
         for(var  i=0;i<this.mappingDetail.length;i++)
         {

           if(this.city==this.mappingDetail[i].Cname && this.k==this.mappingDetail[i].Mvname)
           {
        this.date1.push(this.mappingDetail[i].ShowDate);
        this.date2=(this.date1.toString().split(","));
                console.log("the value of date"+this.date2);
           }
           else
           {
             console.log("no data");
           }

          //  var q = this.date2.split(",");
          //  console(q);
        //  console.log(q);
         }
}
//----------------------------------------------------------------------------------------------

abc()
{
  console.log(this.k);
  // var b=document.getElementById('k').value;
  // console.log(b);
  var json={
          "MovieName":this.k ,
          "Date":this.ShowDate,
          "Time":this.ShowTime,
          "Theater":this.Thname,
          "Loc":this.Lname
          };

          this.$http.post('/api/paymentendpoints/fetchBookings',json).then(function( res) {
           console.log( res);
            var g=[];
            for(var j=0; j<=res.data.length; j++){
              var f = res.data[j].Seat.toString();

            // alert(f);
                g =f.split(",");
                 //   console.log("the value of date"+this.s);
                 for(var i =0;i<=g.length;i++)
                 {
                   $("#"+g[i]).addClass("disabledbutton");

                 }
            }
          },
            function(res){
            alert("ERROR")
          });
  // var s = this.s;
    // $(f).addClass("disabledbutton");
//  alert("Hi");
}


 bookingDetails(){
 var nseats = document.getElementById('nseats').value;
 sessionStorage.setItem('nseats',nseats);
 // console.log("value of nseats" +nseats);
 var sno = document.getElementById('sno').value;
 sessionStorage.setItem('sno',sno);
 var amount = document.getElementById('amount').value;
 sessionStorage.setItem('amount',amount);
}

// seatDetails() {
//   this.$http.post('/api/userendpoints', {
//     SelectedSeat: this.bookingDetail,
//     Class: this.bookingDetail,
//     SeatNo: this.bookingDetail,
//     Amount: this.bookingDetail
//   });
// }
}


angular.module('yeomanOnlineTicketBookingApp')
  .component('user', {
    templateUrl: 'app/user/user.html',
    controller: UserComponent,
    controllerAs: 'userCtrl'
  });

})();
