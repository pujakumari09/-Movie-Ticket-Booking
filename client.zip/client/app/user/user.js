'use strict';

angular.module('yeomanOnlineTicketBookingApp')
  .config(function ($routeProvider) {
    $routeProvider
      .when('/user', {
        template: '<user></user>'
      });
  });
