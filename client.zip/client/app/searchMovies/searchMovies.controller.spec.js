'use strict';

describe('Component: SearchMoviesComponent', function () {

  // load the controller's module
  beforeEach(module('yeomanOnlineTicketBookingApp'));

  var SearchMoviesComponent;

  // Initialize the controller and a mock scope
  beforeEach(inject(function ($componentController) {
    SearchMoviesComponent = $componentController('searchMovies', {});
  }));

  it('should ...', function () {
    expect(1).to.equal(1);
  });
});
