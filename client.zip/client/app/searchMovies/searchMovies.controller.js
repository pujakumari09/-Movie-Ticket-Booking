'use strict';

(function(){

class SearchMoviesComponent {
  constructor($http, $scope, socket) {
    this.$http = $http;
    this.socket = socket;
    this.MovieData;
    this.Movies=[];
    this.show="";

    $scope.$on('$destroy', function() {
      socket.unsyncUpdates('searchMoviesendpoints');
    });
  }

  $onInit(){
    this.$http.get('/api/searchMoviesendpoints').then(response => {
        this.Movies = response.data;
        this.socket.syncUpdates('searchMoviesendpoints', this.Movies);
        });
      }


FindMovie() {
  this.$http.get('https://api.themoviedb.org/3/search/movie?api_key=7db1e9349d07052bfc8c37d7f6bcc8e9&query='+this.MovieName+'&year='+this.Year).then(response => {
   console.log(response.data.results[0].id);
    var MovieID = response.data.results[0].id;
    this.$http.get('https://api.themoviedb.org/3/movie/'+MovieID+'?api_key=7db1e9349d07052bfc8c37d7f6bcc8e9').then(movieres =>{
      this.MovieData = movieres.data;
      console.log(this.MovieData);
    });
  });
}


AddMovie(){
this.$http.post('api/searchMoviesendpoints',{
  poster_path: this.MovieData.poster_path,
  title: this.MovieData.title,
  release_date: this.MovieData.release_date,
  genres: this.MovieData.genre_ids,
  runtime: this.MovieData.runtime
});
 this.MovieName = '';
 this.Year = '';
 var poster = this.
 alert('Record Added Successfully');
}

deleteMovies1()
{
  alert("the move name"+this.show);
  var name=this.show;
  var json = {
    "MovieName":this.show
  };


    this.$http.get('/api/mappingendpoints/deleteMovies/'+name);
}


DeleteMovie(searchMovies) {
  this.show = searchMovies.title;
  // alert(this.show);
    this.$http.get('/api/mappingendpoints/deleteMovies/'+searchMovies.title);
  this.$http.delete('/api/searchMoviesendpoints/'+searchMovies._id );
  alert('Record Deleted');
//  this.deleteMovies1();
}

}

angular.module('yeomanOnlineTicketBookingApp')
  .component('searchMovies', {
    templateUrl: 'app/searchMovies/searchMovies.html',
    controller: SearchMoviesComponent,
    controllerAs: 'searchMoviesCtrl'
  });

})();
