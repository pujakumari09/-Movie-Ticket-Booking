'use strict';

describe('Component: ThreaterComponent', function () {

  // load the controller's module
  beforeEach(module('yeomanOnlineTicketBookingApp'));

  var ThreaterComponent;

  // Initialize the controller and a mock scope
  beforeEach(inject(function ($componentController) {
    ThreaterComponent = $componentController('threater', {});
  }));

  it('should ...', function () {
    expect(1).to.equal(1);
  });
});
