'use strict';

(function(){

class ThreaterComponent {
  constructor($http, $scope, socket) {
    this.$http = $http;
    this.socket = socket;
    this.ThreaterDetail = [];

   $scope.$on('$destroy', function() {
     socket.unsyncUpdates('threaterendpoint');
    });
  }

  $onInit() {
    this.$http.get('/api/threaterendpoints').then(response => {
        this.ThreaterDetail = response.data;
        this.socket.syncUpdates('threaterendpoint', this.ThreaterDetail);
      });
    }

      addThreater() {
      this.$http.post('/api/threaterendpoints',{
      ThreaterName: this.ThreaterName,
      LocationName: this.LocationName,
      City: this.City
    });
    this.ThreaterName = '';
    this.LocationName = '';
    this.City = '';
    alert('Details Saved Successfully');
  }

   deleteThreater(threaterendpoint) {
      alert('Deleted the record');
      this.$http.delete('/api/threaterendpoints/'+threaterendpoint._id );
  }
  }


angular.module('yeomanOnlineTicketBookingApp')
  .component('threater', {
    templateUrl: 'app/threater/threater.html',
    controller: ThreaterComponent,
    controllerAs: 'threaterCtrl'
  });

})();
