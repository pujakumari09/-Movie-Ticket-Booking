'use strict';

(function(){

class BookedComponent {
  constructor($http, $scope, socket) {
    this.$http = $http;
    this.socket = socket;
    this.m = [];
    this.c = [];
    this.l =  [];
    this.sd = [];
    this.th = [];
    this.st = [];
    this.nseats = [];
    this.sno = [];
    this.amount = [];
    this.userDetails = [];

    $scope.$on('$destroy', function(){
      socket.unsyncUpdates('paymentendpoint');
    });
  }

  $onInit(){
    this.m = sessionStorage.getItem('mdetail');
    this.c = sessionStorage.getItem('cdetail');
    this.sd = sessionStorage.getItem('sddetail',);
    this.l = sessionStorage.getItem('ldetail');
    this.th = sessionStorage.getItem('thdetail');
    this.st = sessionStorage.getItem('stdetail');
    this.nseats = sessionStorage.getItem('nseats');
    this.sno = sessionStorage.getItem('sno');
    this.amount = sessionStorage.getItem('amount');

    this.$http.get('/api/userendpoints').then(response => {
      this.bookingDetail = response.data;
      this.socket.syncUpdates('userendpoint', this.bookingDetail);
    });
    this.$http.get('/api/paymentendpoints').then(response => {
      this.userDetails = response.data;
      this.socket.syncUpdates('paymentendpoint', this.userDetail);
    });

 }
}

angular.module('yeomanOnlineTicketBookingApp')
  .component('booked', {
    templateUrl: 'app/booked/booked.html',
    controller: BookedComponent,
    controllerAs: 'bookedCtrl'
  });

})();
