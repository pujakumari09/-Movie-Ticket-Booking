'use strict';

angular.module('yeomanOnlineTicketBookingApp')
  .config(function ($routeProvider) {
    $routeProvider
      .when('/payment', {
        template: '<payment></payment>'
      });
  });
