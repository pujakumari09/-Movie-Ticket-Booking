  'use strict';

(function(){

class PaymentComponent {
  constructor($http, $scope, socket) {
    this.$http = $http;
    this.socket = socket;
    this.userDetails = [];
    this.m = [];
    this.c = [];
    this.l =  [];
    this.sd = [];
    this.th = [];
    this.st = [];
    this.nseats = [];
    this.sno = [];
    this.amount = [];

    $scope.submitForm = function(isValid){
      if(isValid){
        alert('Detail is Valid');
      }
    }
   $scope.phoneNumbr = /^\+?\d{2}[- ]?\d{3}[- ]?\d{5}$/;

    $scope.$on('$destroy', function(){
      socket.unsyncUpdates('paymentendpoint');
    });
  }

$onInit(){
  this.m = sessionStorage.getItem('mdetail');
//  console.log("the val of m"+this.m);
//  alert(this.m);
  this.c = sessionStorage.getItem('cdetail');
  this.sd = sessionStorage.getItem('sddetail',);
  this.l = sessionStorage.getItem('ldetail');
  this.th = sessionStorage.getItem('thdetail');
  this.st = sessionStorage.getItem('stdetail');
  this.nseats = sessionStorage.getItem('nseats');
  this.sno = sessionStorage.getItem('sno');
  this.amount = sessionStorage.getItem('amount');

  // if(this.nseats[i] = this.sno[i]){
  //   document.getElementByClassName("dot1").disabled = true;
  // }

  this.$http.get('/api/mappingendpoints').then(response => {
  this.mappingDetail = response.data;
//  console.log(this.mappingDetail);
  this.socket.syncUpdates('mappingendpoint', this.mappingDetail);
  });
  this.$http.get('/api/userendpoints').then(response => {
    this.bookingDetail = response.data;
    this.socket.syncUpdates('userendpoint', this.bookingDetail);
  });
  this.$http.get('/api/paymentendpoints').then(response => {
    this.userDetails = response.data;
    this.socket.syncUpdates('paymentendpoint', this.userDetail);
  });


 }

 allDetails(){
   this.$http.post('/api/paymentendpoints',{
     MovieName: this.m,
     Date: this.sd,
     Time: this.st,
     Theater: this.th,
     Loc: this.l,
     Nseats: this.nseats,
     Seat: this.sno,
     Amount: this.amount
   });
}

}

angular.module('yeomanOnlineTicketBookingApp')
  .component('payment', {
    templateUrl: 'app/payment/payment.html',
    controller: PaymentComponent,
    controllerAs: 'paymentCtrl'
  });

})();
