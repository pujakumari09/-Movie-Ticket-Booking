(function(angular, undefined) {
  angular.module("yeomanOnlineTicketBookingApp.constants", [])

.constant("appConfig", {
	"userRoles": [
		"guest",
		"user",
		"admin"
	]
})

;
})(angular);