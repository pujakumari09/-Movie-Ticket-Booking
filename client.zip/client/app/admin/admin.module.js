'use strict';

angular.module('yeomanOnlineTicketBookingApp.admin', ['yeomanOnlineTicketBookingApp.auth',
  'ngRoute'
]);
