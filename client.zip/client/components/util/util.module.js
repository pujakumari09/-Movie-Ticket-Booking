'use strict';

angular.module('yeomanOnlineTicketBookingApp.util', []);
